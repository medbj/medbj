---
title: Boundaries that leave room for kindness
description: Simple words for saying what you can offer and what you need.
date: 2026-11-06
updated: 2026-11-06
slug: boundaries-that-leave-room-for-kindness
category: relationships
tags:
  - relationships
author: Editorial team
reviewedOn: null
keyTakeaways:
  - A boundary describes a limit or a choice you can make.
  - Clear, simple language can leave less room for guessing.
  - Safety and power differences matter when deciding what to say.
references:
  - title: 'Mind: Looking after yourself'
    url: https://www.mind.org.uk/information-support/tips-for-everyday-living/wellbeing/
sensitive: false
draft: false
sample: true
lang: en
dir: ltr
visual: paths
---

You may want to support someone and still need time, privacy, or rest. Holding both of those things can feel uncomfortable. You might worry that a limit will sound unkind or make a relationship more difficult.

A boundary is a way to describe what you can offer, what you need, or what you will do. It is not a promise that another person will like your decision.

## Begin with the actual limit

Try to name the practical point. Are you unavailable at a certain time? Do you need a conversation to happen without shouting? Is a request more than you can take on?

A clear sentence might be: “I cannot help on Saturday,” or “I can listen for a little while, then I need to leave.” You can be warm without making the limit vague.

You do not have to provide a long explanation. In some situations, a short reason is useful. In others, extra detail creates more things to debate.

## Offer only what you can genuinely offer

You may want to suggest another time or a different kind of help. Do so only if it works for you. “I cannot do this, but I can help with that” is an option, not a requirement.

You can also ask for time before answering: “I need to check what is possible. I will let you know tomorrow.” This gives you room to make a decision rather than agreeing under pressure.

## Expect feelings without taking charge of them

Someone may feel disappointed. You may feel guilty. Those feelings can be part of a conversation without deciding the whole outcome.

You can acknowledge the other person while keeping your meaning clear: “I understand this is difficult. I am still not available.” A boundary is not a way to control their response.

## Put safety first

Not every relationship allows a safe, direct conversation. Power, money, housing, and the risk of harm can affect your choices. If saying no could put you at risk, seek confidential advice from an appropriate local service or trusted professional.

You do not have to use a communication exercise to manage an unsafe situation on your own.
