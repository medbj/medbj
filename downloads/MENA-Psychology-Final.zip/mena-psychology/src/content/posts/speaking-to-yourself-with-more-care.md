---
title: Speaking to yourself with more care
description: Find words that are honest without making a hard moment harsher.
date: 2026-11-06
updated: 2026-11-06
slug: speaking-to-yourself-with-more-care
category: self-esteem
tags:
  - self-esteem
author: Editorial team
reviewedOn: null
keyTakeaways:
  - A mistake describes an event, not your whole worth.
  - Kind self-talk can be realistic rather than relentlessly positive.
  - You can practise a different response without feeling convinced at once.
references:
  - title: 'NHS: Raising low self-esteem'
    url: https://www.nhs.uk/mental-health/self-help/tips-and-support/raise-low-self-esteem/
sensitive: false
draft: false
sample: true
lang: en
dir: ltr
visual: stones
---

After a mistake, your first thought might be a harsh one: “I always get this wrong.” A difficult moment becomes a statement about who you are. It can be hard to find a different response when those words feel familiar.

Speaking to yourself with care does not mean pretending that everything went well. You can be honest about a problem without making it a judgment about your whole worth.

## Describe what happened

Try replacing a broad label with a specific description. “I am useless” might become “I forgot that appointment.” The second sentence still names the problem. It also leaves room for a next step.

You might need to apologise, repair something, or change a plan. None of those actions requires calling yourself names.

## Look for a fairer sentence

Ask what you would say to a person you care about in the same situation. You might acknowledge that it hurts, notice what was difficult, and help them work out what to do next.

You can use that same structure for yourself: “I am disappointed. I was managing a lot. I will check whether I can rearrange it.” A fair sentence can include responsibility and kindness together.

## Do not force a positive feeling

New words may feel awkward or unconvincing. You do not need to repeat a claim that feels false, such as “I am great at everything.” A neutral sentence can be enough: “This is one difficult moment.”

Notice whether the words help you respond more usefully. If an exercise makes you feel worse, you can stop or try a different approach.

## Make room for outside support

The way you speak to yourself may be shaped by relationships, discrimination, or repeated criticism. It is not simply a personal habit you should be able to fix alone.

A trusted person or qualified professional can help you talk through patterns that feel painful or hard to change. If these thoughts are affecting daily life, reaching out is a reasonable next step.
